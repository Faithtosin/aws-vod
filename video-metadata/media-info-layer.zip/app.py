import json
import pprint
import logging
import boto3
import botocore
import subprocess
import os
from botocore.config import Config


SIGNED_URL_EXPIRATION = 300     # The number of seconds that the Signed URL is valid
region = os.environ['AWS_REGION']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """

    :param event:
    :param context:
    """
    # Loop through records provided by S3 Event trigger
    for s3_record in event['Records']:
        logger.info("Working on new s3_record...")
        # Extract the Key and Bucket names for the asset uploaded to S3
        key = s3_record['s3']['object']['key']
        bucket = s3_record['s3']['bucket']['name']
        logger.info("Bucket: {} \t Key: {}".format(bucket, key))

        # Generate a signed URL for the uploaded asset
        signed_url = get_signed_url(SIGNED_URL_EXPIRATION, bucket, key)
        #logger.info("Signed URL: {}".format(signed_url))
        # Launch MediaInfo
        json_output = subprocess.check_output(["./mediainfo", "--full", "--output=JSON", signed_url])
        #media_info = subprocess.check_output(["./mediainfo", signed_url])

        #logger.info("Output: {}".format(json_output))
        logger.info("Try 1--------------------------")
        logger.info(json_output)
        logger.info("Try 2--------------------------")
        logger.info(json.loads(json_output))
        # Finish the Lambda function with an HTTP 200 status code:
        json_output = json.loads(json_output)
        Body = json.dumps(json_output, indent=4)
        s3 = boto3.resource('s3')
        s3.Bucket(bucket).put_object(Key='test.json', Body=Body)
        return Body
        
        
        


def get_signed_url(expires_in, bucket, obj):
    """
    Generate a signed URL
    :param expires_in:  URL Expiration time in seconds
    :param bucket:
    :param obj:         S3 Key name
    :return:            Signed URL
    """
    s3_cli = boto3.client("s3", region_name=region, config = Config(signature_version = 's3v4', s3={'addressing_style': 'virtual'}))
    presigned_url = s3_cli.generate_presigned_url('get_object', Params={'Bucket': bucket, 'Key': obj}, ExpiresIn=expires_in)
    return presigned_url